## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/react-js-academy-for-beginners-with-firebase-video/9781839216251)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# React.js-Academy-for-Beginners-with-Firebase
Code Repository for React.js Academy for Beginners with Firebase, Published by Packt
